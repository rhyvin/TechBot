package ta;

public class Constants {

    public static final String prefix = "~";

    public static final long OWNER = 255934842078756864L;

}
