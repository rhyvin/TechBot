package ta.util;

class DSecrets {

    static final String HOST = "";
    static final String UNAME = "";
    static final String UPASS = "";
}
