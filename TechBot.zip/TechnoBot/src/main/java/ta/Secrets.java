package ta;

class Secrets {

    static final String TOKEN = "NTYwMTk4NDIwMDE1NjExOTI0.XL4hew.8o-VkKYPXhucK36J8N2f5aMDLRs";


}
